# My first mod

Gives railgunner a new passive that re-enables crit chance