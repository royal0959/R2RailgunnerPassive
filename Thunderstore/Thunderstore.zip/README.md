# RailgunnerCritChancePassive

![AtomStabilizer](https://github.com/royal0959/R2RailgunnerPassive/blob/main/AtomStabilizerStats.png?raw=true)

plus an extra ``No Passive`` choice for players who don't want the attack speed bonus

![NoPassive](https://github.com/royal0959/R2RailgunnerPassive/blob/main/NoPassiveStats.png?raw=true)

# Credits
``colonel`` - Idea

``me^2`` - Icon for Atom Stabilizer
